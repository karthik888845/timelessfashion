var sidenavbar = document.querySelector(".side-navbar")

function showNavbar()
{
     sidenavbar.style.left="0"
}

function closeNavbar()
{
     sidenavbar.style.left="-60%"
}